
/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

//para copiar y pegar en el main y probar cosas

package thisfr;

import thisfr.Characters.*;
import thisfr.Races.*;
import thisfr.CharacterClasses.*;

public class TestCharacters {
    public static void main(String[] args) {
        // 1️⃣ Base attributes (10 in every stat)
        Attributes baseAttributes = new Attributes(10, 10, 10, 10, 10, 10);

        // 2️⃣ Pick race & apply racial bonus
        Race race = new Elf();
        race.applyRacialBonus(baseAttributes);

        // 3️⃣ Pick a class (change to Fighter(), Rogue(), Wizard() to test)
        CharacterClass charClass = new Wizard();

        // 4️⃣ Create a simple proficiency object (can use class defaults too)
        Proficiencies profs = charClass.getProficiencies();

        // 5️⃣ Build the character
        DnDCharacter hero = new DnDCharacter(
            "Aerendil",
            race,
            charClass,
            1,
            baseAttributes,
            profs
        );

        // 6️⃣ Print the result
        System.out.println("===== Character Sheet =====");
        System.out.println("Name: " + hero.getName());
        System.out.println("Race: " + hero.getRace().getName());
        System.out.println("Class: " + hero.getCharClass().getName());
        System.out.println("Level: " + hero.getLevel());
        System.out.println("Attributes: " + hero.getAttributes());
        System.out.println("\nProficiencies:");
        System.out.println(" Armor: " + profs.getArmor());
        System.out.println(" Weapons: " + profs.getWeapons());
        System.out.println(" Tools: " + profs.getTools());
        System.out.println(" Saving Throws: " + profs.getSavingThrows());
        System.out.println(" Skills: " + profs.getSkills());
    }
}