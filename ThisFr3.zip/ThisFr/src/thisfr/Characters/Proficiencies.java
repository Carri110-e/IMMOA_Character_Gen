package thisfr.Characters;

import java.util.List;

public class Proficiencies {

    // --- Fields ---
    private List<String> armor;
    private List<String> weapons;
    private List<String> tools;
    private List<String> savingThrows;
    private List<String> skills;

    // --- Constructor ---
    public Proficiencies(List<String> armor, List<String> weapons,
                         List<String> tools, List<String> savingThrows,
                         List<String> skills) {
        this.armor = armor;
        this.weapons = weapons;
        this.tools = tools;
        this.savingThrows = savingThrows;
        this.skills = skills;
    }

    public List<String> getArmor() {
        return armor;}
    public void setArmor(List<String> armor) {
        this.armor = armor;}
    public List<String> getWeapons() {
        return weapons;}
    public void setWeapons(List<String> weapons) {
        this.weapons = weapons;}
    public List<String> getTools() {
        return tools;}
    public void setTools(List<String> tools) {
        this.tools = tools;}
    public List<String> getSavingThrows() {
        return savingThrows;}
    public void setSavingThrows(List<String> savingThrows) {
        this.savingThrows = savingThrows;}
    public List<String> getSkills() {
        return skills;}
    public void setSkills(List<String> skills) {
        this.skills = skills;}
}
