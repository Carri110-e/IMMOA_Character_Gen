package thisfr.Characters;

import java.util.ArrayList;
import java.util.List;
import thisfr.Races.Race;
import thisfr.CharacterClasses.CharacterClass;
import thisfr.Feats.*;

public class DnDCharacter {
    private String name;
    private Race race;
    private CharacterClass charClass;
    private int level;
    private Attributes attributes;
    private Proficiencies proficiencies;
    private int maxHp;
    private final List<Feat> feats = new ArrayList<>(); // optional feats
    private int armorClass;

    //  Constructor
    public DnDCharacter(String name, Race race, CharacterClass charClass, int level,
                        Attributes attributes, Proficiencies proficiencies) {
        this.name = name;
        this.race = race;
        this.charClass = charClass;
        this.level = level;
        this.attributes = attributes;
        this.proficiencies = proficiencies;
        this.armorClass = computeArmorClass();     
        this.maxHp = computeMaxHpUsingAverage();
    }

    // ---- HP logic ----
    private int sumFeatLevel1Bonus() {
        int sum = 0;
        for (Feat f : feats) sum += f.bonusHpLevel1();
        return sum;
    }
    private int sumFeatPerLevelBonus() {
        int sum = 0;
        for (Feat f : feats) sum += f.bonusHpPerLevel();
        return sum;
    }

    private int computeMaxHpUsingAverage() {
        int conMod = attributes.conMod();

        // Level 1: full hit die + CON mod + racial L1 + feat L1
        int hp = charClass.getHitDie()
               + conMod
               + race.bonusHpLevel1()
               + sumFeatLevel1Bonus();

        // Levels 2..N: average per level + CON mod + racial/feat per-level
        int perLevelBonus = race.bonusHpPerLevel() + sumFeatPerLevelBonus();
        for (int lvl = 2; lvl <= level; lvl++) {
            hp += charClass.averagePerLevel() + conMod + perLevelBonus;
        }
        return Math.max(1, hp);
    }/** Level up by 1 using average HP gain. */
    
    public void levelUp() {
        level++;
        int conMod = attributes.conMod();
        int perLevelBonus = race.bonusHpPerLevel() + sumFeatPerLevelBonus();
        maxHp += charClass.averagePerLevel() + conMod + perLevelBonus;
        // Delegate class-specific stuff if you want:
        charClass.levelUp(attributes);
    }

    //AC
    private int computeArmorClass() {
        // Basic unarmored formula for now
        return 10 + attributes.dexMod();
    }
    public int getArmorClass() {
        return armorClass;
    }

    // ---- Feats management ----
    public void addFeat(Feat feat) {
        feats.add(feat);
        // Recompute HP from scratch since feats can change per-level bonus
        this.maxHp = computeMaxHpUsingAverage();
    }
    public int getProficiencyBonus() {
    // +2 at lvl 1–4, +3 at 5–8, +4 at 9–12, +5 at 13–16, +6 at 17–20
    return 2 + (level - 1) / 4;
    }

    // ---- Getters ----
    public String getName() { return name; }
    public Race getRace() { return race; }
    public CharacterClass getCharClass() { return charClass; }
    public int getLevel() { return level; }
    public Attributes getAttributes() { return attributes; }
    public Proficiencies getProficiencies() { return proficiencies; }
    public int getMaxHp() { return maxHp; }
    
    @Override
public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("====================================\n");
    sb.append(String.format("%s the %s %s (Lvl %d)\n",
            name, race.getName(), charClass.getName(), level));
    sb.append("------------------------------------\n");
    sb.append(String.format("Hit Points: %d\n", maxHp));
    sb.append(String.format("Proficiency Bonus: +%d\n", getProficiencyBonus()));
    sb.append("\nAttributes:\n");
    sb.append(attributes.display()); // this will call the method we’ll add next
    sb.append("\nProficiencies:\n");
    sb.append(" Armor: " + proficiencies.getArmor() + "\n");
    sb.append(" Weapons: " + proficiencies.getWeapons() + "\n");
    sb.append(" Tools: " + proficiencies.getTools() + "\n");
    sb.append(" Saving Throws: " + proficiencies.getSavingThrows() + "\n");
    sb.append(" Skills: " + proficiencies.getSkills() + "\n");
    sb.append("====================================\n");
    return sb.toString();
    }
}