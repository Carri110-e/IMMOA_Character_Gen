package thisfr;

import thisfr.Characters.*;
import thisfr.Races.*;
import thisfr.CharacterClasses.*;
import thisfr.Feats.*;

public class TestHP {
    public static void main(String[] args) {
        Attributes a = new Attributes(15, 10, 14, 8, 10, 10); // CON 14 => +2
        Race race = new Dwarf();          // base Dwarf: no HP bonus by default
        CharacterClass cc = new Fighter();// d10 → lvl1: 10, per level: +6 avg
        Proficiencies profs = cc.getProficiencies();

        DnDCharacter c = new DnDCharacter("Brak", race, cc, 1, a, profs);
        System.out.println(c); // Expect level1 HP = 10 + CON(+2) = 12

        c.levelUp(); // +6 (avg d10) +2 CON = +8 → HP 20
        System.out.println("After level up → Lvl " + c.getLevel() + " HP " + c.getMaxHp());

        // Add Tough feat and recompute
        c.addFeat(new Tough()); // +2 per level → lvl2 should become 22 (recomputed)
        System.out.println("After Tough feat → HP " + c.getMaxHp());
    }
}