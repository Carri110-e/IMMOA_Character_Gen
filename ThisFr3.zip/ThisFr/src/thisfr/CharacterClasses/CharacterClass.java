/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package thisfr.CharacterClasses;
import thisfr.Utils.Dice;
import thisfr.Characters.*;


/**
 *
 * @author Squal
 */
public abstract class CharacterClass {
    protected String name;
    protected int hitDie;  // e.g. Fighter = 10, Rogue = 8, Wizard = 6
    protected Proficiencies proficiencies;
    public boolean isSpellcaster() { return false; }

    public CharacterClass(String name, int hitDie, Proficiencies proficiencies) {
        this.name = name;
        this.hitDie = hitDie;
        this.proficiencies = proficiencies;
    }
    
    
    public String getName() {
        return name;
    }
    public int getHitDie() {
        return hitDie;
    }
    public Proficiencies getProficiencies() {
        return proficiencies;
    }
    public int getSpellSlots(int characterLevel, int spellLevel) {
        return 0; // default – non-casters
    }

    // each class can implement how it levels up
    public abstract void levelUp(Attributes attributes);
    
    public int averagePerLevel() {
        // 5e fixed averages: d6→4, d8→5, d10→6, d12→7
        switch (hitDie) {
            case 6:  return 4;
            case 8:  return 5;
            case 10: return 6;
            case 12: return 7;
            default: return Math.max(1, (hitDie + 1) / 2); // fallback
        }
    }
    public int attackRoll(Attributes attributes, int proficiencyBonus) {
    int roll = Dice.d20();
    int modifier = attributes.strMod(); // default: STR-based attacks
    return roll + modifier + proficiencyBonus;
    }

    @Override
    public String toString() {
        return name;
    }
}