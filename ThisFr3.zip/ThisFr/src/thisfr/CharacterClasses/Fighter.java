/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package thisfr.CharacterClasses;
import thisfr.Characters.Attributes;
import thisfr.Characters.Proficiencies;
import java.util.List;
import java.util.Arrays;

public class Fighter extends CharacterClass {

    public Fighter() {
        super("Fighter", 10, new Proficiencies(
            Arrays.asList("Light Armor", "Medium Armor", "Heavy Armor", "Shields"),
            Arrays.asList("Simple Weapons", "Martial Weapons"),
            List.of(),
            Arrays.asList("Strength", "Constitution"),
            Arrays.asList("Athletics", "Survival")
        ));
    }

    @Override
    public void levelUp(Attributes attributes) {
        System.out.println("Fighter levels up! Gains extra attack at level 5 (later).");
        // optional: add +1 Strength, etc.
    }
}
