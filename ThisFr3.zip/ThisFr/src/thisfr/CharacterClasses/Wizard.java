/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package thisfr.CharacterClasses;
import thisfr.Characters.Attributes;
import thisfr.Characters.Proficiencies;
import java.util.Arrays;
import java.util.List;
import thisfr.Spells.Spell;
import thisfr.Spells.SpellBook;
import thisfr.Utils.Dice;

public class Wizard extends CharacterClass {
    private SpellBook spellBook;
    
    public Wizard() {
        super("Wizard", 6, new Proficiencies(
            Arrays.asList("None"), // wizards don't have armor proficiencies
            Arrays.asList("Daggers", "Darts", "Slings", "Quarterstaffs", "Light Crossbows"),
            Arrays.asList("None"),
            Arrays.asList("Intelligence", "Wisdom"),
            Arrays.asList("Arcana", "History")
        ));
        spellBook = new SpellBook();
        // starter spells
        spellBook.learnSpell(new Spell("Fire Bolt", 0, "1d10 fire", "A bolt of fire leaps from your hand."));
        spellBook.learnSpell(new Spell("Magic Missile", 1, "1d4+1 force", "Three glowing darts hit automatically."));
    }

    @Override
    public void levelUp(Attributes attributes) {
        System.out.println("Wizard levels up – gains new spells and slots.");
        // Example – add one new spell each level
        if (attributes.intMod() >= 2)
            spellBook.learnSpell(new Spell("Burning Hands", 1, "3d6 fire", "A cone of flames erupts from your fingers."));
    }
    @Override
    public int attackRoll(Attributes attributes, int proficiencyBonus) {
        int roll = Dice.d20();
        int modifier = attributes.intMod(); // spell attacks
        return roll + modifier + proficiencyBonus;
    }
    @Override
    public boolean isSpellcaster() { return true; }
    @Override
    public int getSpellSlots(int characterLevel, int spellLevel) {
        // Minimal version of PHB table (level → # level-1 slots)
        int[][] slotTable = {
            {0}, {2}, {3}, {4}, {4}, {4}, {4}, {4}, {4}, {4}
        };
        if (spellLevel == 1 && characterLevel < slotTable.length)
            return slotTable[characterLevel][0];
        return 0;
    }

    public SpellBook getSpellBook() { return spellBook; }
}
