/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package thisfr.CharacterClasses;
import thisfr.Characters.Attributes;
import thisfr.Characters.Proficiencies;
import java.util.Arrays;
import java.util.List;
import thisfr.Utils.Dice;

public class Rogue extends CharacterClass {

    public Rogue() {
        super("Rogue", 8, new Proficiencies(
            Arrays.asList("Light Armor"),
            Arrays.asList("Simple Weapons", "Hand Crossbows", "Longswords", "Rapiers", "Shortswords"),
            Arrays.asList("Thieves' Tools"),
            Arrays.asList("Dexterity", "Intelligence"),
            Arrays.asList("Stealth", "Acrobatics")
        ));
    }

    @Override
    public void levelUp(Attributes attributes) {
        System.out.println("Rogue levels up! Gains Sneak Attack damage increase (later).");
        // you could also boost dexterity slightly
        // attributes.addDexterity(1);
    }
    @Override
    public int attackRoll(Attributes attributes, int proficiencyBonus) {
        int roll = Dice.d20();
        int modifier = attributes.dexMod(); // DEX-based for finesse weapons
        return roll + modifier + proficiencyBonus;
    }
}
