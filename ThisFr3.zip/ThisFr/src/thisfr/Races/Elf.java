/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package thisfr.Races;

import thisfr.Characters.Attributes;

/**
 *
 * @author Squal
 */
public class Elf extends Race {
    public Elf() {
        super("Elf");
    }

    @Override
    public void applyRacialBonus(Attributes attributes) {
        attributes.addDexterity(2);
    }
}
