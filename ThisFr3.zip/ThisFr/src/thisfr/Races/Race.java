/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package thisfr.Races;

import thisfr.Characters.Attributes;

/**
 *
 * @author Squal
 */
public abstract class Race {
    protected String name;
    public Race(String name) { this.name = name; }
    public String getName() { return name; }

    public abstract void applyRacialBonus(Attributes attributes);

    // HP bonuses (override in subraces later; default 0)
    public int bonusHpLevel1()    { return 0; }
    public int bonusHpPerLevel()  { return 0; }

    @Override public String toString() { return name; }
}