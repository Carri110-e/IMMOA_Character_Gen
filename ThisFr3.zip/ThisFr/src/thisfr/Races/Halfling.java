/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package thisfr.Races;

import thisfr.Characters.Attributes;

/**
 *
 * @author Squal
 */
public class Halfling extends Race {
    public Halfling() {
        super("Halfling");
    }

    @Override
    public void applyRacialBonus(Attributes attributes) {
        attributes.addDexterity(2);
        attributes.addCharisma(1);
    }
}
