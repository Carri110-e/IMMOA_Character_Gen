/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package thisfr.Races;

import thisfr.Characters.Attributes;

/**
 *
 * @author Squal
 */
public class Human extends Race {
    public Human() {
        super("Human");
    }

    @Override
    public void applyRacialBonus(Attributes attributes) {
        attributes.addToAll(1);
    }
}