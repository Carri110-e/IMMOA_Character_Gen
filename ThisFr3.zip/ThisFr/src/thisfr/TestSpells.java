package thisfr;

import thisfr.Characters.*;
import thisfr.Races.*;
import thisfr.CharacterClasses.*;
import thisfr.Spells.*;

public class TestSpells {
    public static void main(String[] args) {
        Attributes stats = new Attributes(8, 12, 10, 16, 10, 10);
        Race race = new Elf();
        Wizard wiz = new Wizard();

        DnDCharacter merlin = new DnDCharacter("Merlin", race, wiz, 3,
                stats, wiz.getProficiencies());

        System.out.println(merlin);
        System.out.println("\nSpellbook:");
        wiz.getSpellBook().listSpells();

        int slots = wiz.getSpellSlots(3, 1);
        System.out.println("\nSpell Slots (Lvl 1 at character lvl 3): " + slots);
    }
}