package thisfr;

import thisfr.Characters.*;
import thisfr.Races.*;
import thisfr.CharacterClasses.*;
import thisfr.Utils.Dice;

public class TestCombat {
    public static void main(String[] args) {
        Attributes heroStats = new Attributes(16, 14, 12, 8, 10, 10);
        Race heroRace = new Human();
        CharacterClass heroClass = new Fighter();
        DnDCharacter hero = new DnDCharacter("Brak", heroRace, heroClass, 3,
                heroStats, heroClass.getProficiencies());

        Attributes dummyStats = new Attributes(10, 10, 10, 10, 10, 10);
        DnDCharacter dummy = new DnDCharacter("Training Dummy",
                new Human(), new Wizard(), 1,
                dummyStats, new Wizard().getProficiencies());

        System.out.println(hero);
        System.out.println("Enemy AC: " + dummy.getArmorClass());

        // Roll an attack
        int attackTotal = hero.getCharClass()
                .attackRoll(hero.getAttributes(), hero.getProficiencyBonus());

        int roll = attackTotal - hero.getAttributes().strMod() - hero.getProficiencyBonus();
        System.out.printf("\nAttack Roll: d20(%d) + STR(%+d) + PROF(+%d) = %d\n",
                roll, hero.getAttributes().strMod(), hero.getProficiencyBonus(), attackTotal);

        if (attackTotal >= dummy.getArmorClass()) {
            int damage = Dice.d(8) + hero.getAttributes().strMod();
            System.out.println("Hit! Damage: " + damage);
        } else {
            System.out.println("Miss!");
        }
    }
}