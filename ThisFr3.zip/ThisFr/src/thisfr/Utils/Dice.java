package thisfr.Utils;
import java.util.Random;

public class Dice {
    private static final Random RNG = new Random();

    /** Rolls one die of N sides (e.g., d20, d6, etc.) */
    public static int d(int sides) {
        return 1 + RNG.nextInt(sides);
    }

    /** Rolls multiple dice of N sides (e.g., 2d6, 3d8) */
    public static int roll(int diceCount, int sides) {
        int total = 0;
        for (int i = 0; i < diceCount; i++) {
            total += d(sides);
        }
        return total;
    }

    /** Rolls a d20 and returns the result */
    public static int d20() {
        return d(20);
    }
}
