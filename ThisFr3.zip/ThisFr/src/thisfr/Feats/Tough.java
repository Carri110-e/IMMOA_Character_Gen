/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package thisfr.Feats;

/**
 *
 * @author Squal
 */
public class Tough implements Feat {
    @Override public int bonusHpPerLevel() { return 2; } // RAW Tough: +2 per level
}
