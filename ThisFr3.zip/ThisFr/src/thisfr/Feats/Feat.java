package thisfr.Feats;

public interface Feat {
    default int bonusHpLevel1()   { return 0; }
    default int bonusHpPerLevel() { return 0; }
}

