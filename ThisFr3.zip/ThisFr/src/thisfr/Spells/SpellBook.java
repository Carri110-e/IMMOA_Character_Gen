package thisfr.Spells;
import java.util.ArrayList;
import java.util.List;

public class SpellBook {
    private List<Spell> knownSpells = new ArrayList<>();

    public void learnSpell(Spell spell) {
        if (!knownSpells.contains(spell)) {
            knownSpells.add(spell);
        }
    }

    public List<Spell> getKnownSpells() {
        return knownSpells;
    }

    public void listSpells() {
        if (knownSpells.isEmpty()) {
            System.out.println("No spells known yet.");
            return;
        }
        System.out.println("Known Spells:");
        for (Spell s : knownSpells) {
            System.out.println(" • " + s);
        }
    }
}
