package thisfr.Spells;

public class Spell {
    private String name;
    private int level;             // 0 = cantrip, 1–9 = spell level
    private String damage;         // e.g. "2d6 fire"
    private String description;

    public Spell(String name, int level, String damage, String description) {
        this.name = name;
        this.level = level;
        this.damage = damage;
        this.description = description;
    }
    
    // ---- Getters ----
    public String getName() { return name; }
    public int getLevel() { return level; }
    public String getDamage() { return damage; }
    public String getDescription() { return description; }

    @Override
    public String toString() {
        return String.format("%s (Lvl %d) – %s – %s",
                name, level, damage, description);
    }
}
