package thisfr;

import thisfr.Characters.*;
import thisfr.Races.*;
import thisfr.CharacterClasses.*;
import thisfr.Feats.*;

public class NewToString {
    
    public static void main(String[] args) {
    DnDCharacter hero = new DnDCharacter(
    "Aerendil", new Elf(), new Wizard(), 3,
    new Attributes(10, 14, 12, 16, 10, 11),
    new Wizard().getProficiencies()
);

    System.out.println(hero);

    }
}