using System.Windows;

namespace IMMOAwpf
{
    public partial class ConfigWindow : Window
    {
        public ConfigWindow()
        {
            InitializeComponent();

            // do not show current COutputPath (requirement)
            CustomPathBox.Text = AppConfig.CustomCOutputPath ?? string.Empty;
        }

        private void SaveBtn_Click(object sender, RoutedEventArgs e)
        {
            var path = CustomPathBox.Text?.Trim() ?? string.Empty;
            AppConfig.Save(path);
            this.Close();
        }
    }
}
