using System;
using System.IO;
using System.Text.Json;

namespace IMMOAwpf
{
    public class AppConfigData
    {
        public string CustomCOutputPath { get; set; } = string.Empty;
    }

    public static class AppConfig
    {
        private static readonly string ConfigFile = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "appconfig.json");
        public static string CustomCOutputPath { get; private set; } = string.Empty;

        public static void Load()
        {
            try
            {
                if (!File.Exists(ConfigFile)) return;
                var text = File.ReadAllText(ConfigFile);
                var data = JsonSerializer.Deserialize<AppConfigData>(text);
                if (data != null)
                {
                    CustomCOutputPath = data.CustomCOutputPath ?? string.Empty;
                }
            }
            catch
            {
                // ignore
            }
        }

        public static void Save(string customPath)
        {
            try
            {
                var data = new AppConfigData
                {
                    CustomCOutputPath = customPath ?? string.Empty
                };
                var json = JsonSerializer.Serialize(data, new JsonSerializerOptions { WriteIndented = true });
                File.WriteAllText(ConfigFile, json);
                CustomCOutputPath = data.CustomCOutputPath;
            }
            catch
            {
                // ignore
            }
        }
    }
}
