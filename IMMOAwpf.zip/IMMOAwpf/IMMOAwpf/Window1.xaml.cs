﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows;
using System.Windows.Media;
using System.Windows.Media.Imaging;

namespace IMMOAwpf
{
    /// <summary>
    /// Lógica de interacción para Window1.xaml
    /// </summary>
    public partial class Window1 : Window
    {
        private readonly string[] _races = new[]
        {
            "Human", "Elf", "Dwarf", "Halfling", "Gnome", "Half-Elf", "Half-Orc", "Tiefling"
        };

        private readonly string[] _classes = new[]
        {
            "Fighter", "Wizard", "Rogue", "Cleric", "Paladin", "Ranger", "Bard", "Barbarian", "Monk", "Warlock", "Sorcerer", "Druid"
        };

        private int _raceIndex = 0;
        private int _classIndex = 0;

        // Appearance options
        private readonly string[] _hairstyles = new[] { "Default", "Short", "Long", "Ponytail" };
        private readonly string[] _hairColors = new[] { "Brown", "Blonde", "Black", "Red" };
        private readonly string[] _facialHair = new[] { "None", "Mustache", "Beard" };
        private readonly string[] _skinTones = new[] { "Light", "Medium", "Dark" };

        private int _hairstyleIndex = 0;
        private int _hairColorIndex = 0;
        private int _facialHairIndex = 0;
        private int _skinToneIndex = 0;

        private List<string> _selectedProficiencies = new List<string>();
        private int _editingIndex = -1;

        public Window1(Character character = null, int index = -1)
        {
            InitializeComponent();
            // Inicializa textos desde las listas
            RaceTextBlock.Text = _races[_raceIndex];
            ClassTextBlock.Text = _classes[_classIndex];

            HairstyleText.Text = _hairstyles[_hairstyleIndex];
            HairColorText.Text = _hairColors[_hairColorIndex];
            FacialHairText.Text = _facialHair[_facialHairIndex];
            SkinToneText.Text = _skinTones[_skinToneIndex];

            LoadBackgroundImageSafely();

            if (character != null)
            {
                // populate UI controls from existing character
                _editingIndex = index;
                NameTextBox.Text = character.Name;
                _raceIndex = Array.IndexOf(_races, character.Race) >= 0 ? Array.IndexOf(_races, character.Race) : 0;
                RaceTextBlock.Text = _races[_raceIndex];
                _classIndex = Array.IndexOf(_classes, character.Class) >= 0 ? Array.IndexOf(_classes, character.Class) : 0;
                ClassTextBlock.Text = _classes[_classIndex];

                StrBox.Text = character.Strength.ToString();
                DexBox.Text = character.Dexterity.ToString();
                ConBox.Text = character.Constitution.ToString();
                IntBox.Text = character.Intelligence.ToString();
                WisBox.Text = character.Wisdom.ToString();
                ChaBox.Text = character.Charisma.ToString();

                HairstyleText.Text = character.Hairstyle;
                HairColorText.Text = character.HairColor;
                FacialHairText.Text = character.FacialHair;
                SkinToneText.Text = character.SkinTone;

                _selectedProficiencies = character.Proficiencies ?? new List<string>();
                if (SelectedProficienciesList != null)
                {
                    SelectedProficienciesList.ItemsSource = null;
                    SelectedProficienciesList.ItemsSource = _selectedProficiencies;
                }

                // Populate advanced controls (except base metadata which is auto-managed)
                try
                {
                    GenderBox.Text = character.Gender.ToString();
                    HeightBox.Text = character.HeightCm.ToString();
                    SpeedBox.Text = character.SpeedFeet.ToString();
                    ClassNameBox.Text = character.ClassName;
                    ClassHitDieBox.Text = character.ClassHitDie.ToString();
                    HpHitDieBox.Text = character.HpHitDie.ToString();
                    HpConModBox.Text = character.HpConMod.ToString();
                    AoeShapeBox.Text = character.AoeShape.ToString();
                    AoeSizeBox.Text = character.AoeSize.ToString();
                    AoeMoveableBox.Text = character.AoeMoveable.ToString();
                    ComponentConsumableBox.Text = character.ComponentConsumable.ToString();
                    ComponentCostBox.Text = character.ComponentCost.ToString();
                    AbilityPermanentBox.Text = character.AbilityPermanent.ToString();
                    EffectPermanentBox.Text = character.EffectPermanent.ToString();
                    ObjectRangeBox.Text = character.ObjectRange.ToString();
                    ObjectDefenseBox.Text = character.ObjectDefense.ToString();
                    ObjectCategoryBox.Text = character.ObjectCategory;
                    ObjectConcentrationBox.Text = character.ObjectConcentration.ToString();
                    ObjectDescriptionBox.Text = character.ObjectDescription;
                    SpellRangeBox.Text = character.SpellRange.ToString();
                    SpellConcentrationBox.Text = character.SpellConcentration.ToString();
                    SpellDescriptionBox.Text = character.SpellDescription;

                    ArmorProfsBox.Text = string.Join(";", character.ArmorProfs ?? new List<string>());
                    WeaponProfsBox.Text = string.Join(";", character.WeaponProfs ?? new List<string>());
                    ToolProfsBox.Text = string.Join(";", character.ToolProfs ?? new List<string>());
                    SavingThrowProfsBox.Text = string.Join(";", character.SavingThrowProfs ?? new List<string>());
                    SkillProfsBox.Text = string.Join(";", character.SkillProfs ?? new List<string>());

                    // do not populate Base fields here (auto-generated)
                }
                catch { }
            }

            // ensure we start on first tab
            try
            {
                if (CreatorTabControl != null)
                {
                    CreatorTabControl.SelectedIndex = 0;
                }
            }
            catch { }
        }

        private void LoadBackgroundImageSafely()
        {
            try
            {
                // prefer site of origin file which we copied to output
                var uri = new Uri("pack://siteoforigin:,,,/CharacterSelection.png.png", UriKind.Absolute);
                var bmp = new BitmapImage();
                bmp.BeginInit();
                bmp.UriSource = uri;
                bmp.CacheOption = BitmapCacheOption.OnLoad;
                bmp.EndInit();

                BackgroundImage.Source = bmp;
            }
            catch (Exception)
            {
                // ignore
            }
        }

        private void RacePrevBtn_Click(object sender, RoutedEventArgs e)
        {
            _raceIndex = (_raceIndex - 1 + _races.Length) % _races.Length;
            RaceTextBlock.Text = _races[_raceIndex];
        }

        private void RaceNextBtn_Click(object sender, RoutedEventArgs e)
        {
            _raceIndex = (_raceIndex + 1) % _races.Length;
            RaceTextBlock.Text = _races[_raceIndex];
        }

        private void ClassPrevBtn_Click(object sender, RoutedEventArgs e)
        {
            _classIndex = (_classIndex - 1 + _classes.Length) % _classes.Length;
            ClassTextBlock.Text = _classes[_classIndex];
        }

        private void ClassNextBtn_Click(object sender, RoutedEventArgs e)
        {
            _classIndex = (_classIndex + 1) % _classes.Length;
            ClassTextBlock.Text = _classes[_classIndex];
        }

        private void BackButton_Click(object sender, RoutedEventArgs e)
        {
            // Always go back to main menu (owner or Application.MainWindow)
            try
            {
                if (this.Owner != null)
                {
                    this.Owner.Show();
                }
                else if (Application.Current?.MainWindow != null && Application.Current.MainWindow != this)
                {
                    Application.Current.MainWindow.Show();
                }

                this.Close();
            }
            catch (Exception)
            {
                this.Close();
            }
        }

        private void HairstyleButton_Click(object sender, RoutedEventArgs e)
        {
            _hairstyleIndex = (_hairstyleIndex + 1) % _hairstyles.Length;
            HairstyleText.Text = _hairstyles[_hairstyleIndex];
        }

        private void HairColorButton_Click(object sender, RoutedEventArgs e)
        {
            _hairColorIndex = (_hairColorIndex + 1) % _hairColors.Length;
            HairColorText.Text = _hairColors[_hairColorIndex];
        }

        private void FacialHairButton_Click(object sender, RoutedEventArgs e)
        {
            _facialHairIndex = (_facialHairIndex + 1) % _facialHair.Length;
            FacialHairText.Text = _facialHair[_facialHairIndex];
        }

        private void SkinToneButton_Click(object sender, RoutedEventArgs e)
        {
            _skinToneIndex = (_skinToneIndex + 1) % _skinTones.Length;
            SkinToneText.Text = _skinTones[_skinToneIndex];
        }

        private void PrevAppearance_Click(object sender, RoutedEventArgs e)
        {
            // rotate hairstyle index as a placeholder for appearance pages
            _hairstyleIndex = (_hairstyleIndex - 1 + _hairstyles.Length) % _hairstyles.Length;
            HairstyleText.Text = _hairstyles[_hairstyleIndex];
        }

        private void NextAppearance_Click(object sender, RoutedEventArgs e)
        {
            _hairstyleIndex = (_hairstyleIndex + 1) % _hairstyles.Length;
            HairstyleText.Text = _hairstyles[_hairstyleIndex];
        }

        private void ProficienciesBtn_Click(object sender, RoutedEventArgs e)
        {
            var w = new ProficienciesWindow { Owner = this };
            if (w.ShowDialog() == true)
            {
                _selectedProficiencies = w.Selected;
                if (SelectedProficienciesList != null)
                {
                    SelectedProficienciesList.ItemsSource = null;
                    SelectedProficienciesList.ItemsSource = _selectedProficiencies;
                }
            }
        }

        private Character BuildCharacterFromUI()
        {
            int ParseOrDefault(string s, int def) => int.TryParse(s, out var v) ? v : def;
            decimal ParseDecOrDefault(string s, decimal def) => decimal.TryParse(s, out var v) ? v : def;
            List<string> ParseList(string s)
            {
                if (string.IsNullOrWhiteSpace(s)) return new List<string>();
                return s.Split(new[] { ';', ',' }, StringSplitOptions.RemoveEmptyEntries).Select(x => x.Trim()).Where(x => !string.IsNullOrEmpty(x)).ToList();
            }

            var ch = new Character(
                NameTextBox.Text ?? string.Empty,
                _races[_raceIndex],
                _classes[_classIndex],
                ParseOrDefault(StrBox.Text, 14),
                ParseOrDefault(DexBox.Text, 12),
                ParseOrDefault(ConBox.Text, 16),
                ParseOrDefault(IntBox.Text, 8),
                ParseOrDefault(WisBox.Text, 8),
                ParseOrDefault(ChaBox.Text, 10),
                HairstyleText.Text,
                HairColorText.Text,
                FacialHairText.Text,
                SkinToneText.Text,
                _selectedProficiencies,
                // additional fields read from controls
                ParseOrDefault(GenderBox.Text, 1),
                ParseOrDefault(HeightBox.Text, 170),
                ParseOrDefault(SpeedBox.Text, 30),
                ClassNameBox.Text ?? string.Empty,
                ParseOrDefault(ClassHitDieBox.Text, 8),
                ParseOrDefault(HpHitDieBox.Text, ParseOrDefault(ClassHitDieBox.Text, 8)),
                ParseOrDefault(HpConModBox.Text, 0),
                ParseOrDefault(AoeShapeBox.Text, 0),
                ParseOrDefault(AoeSizeBox.Text, 0),
                ParseOrDefault(AoeMoveableBox.Text, 0),
                ParseOrDefault(ComponentConsumableBox.Text, 0),
                ParseDecOrDefault(ComponentCostBox.Text, 0m),
                ParseOrDefault(AbilityPermanentBox.Text, 0),
                ParseOrDefault(EffectPermanentBox.Text, 0),
                ParseOrDefault(ObjectRangeBox.Text, 0),
                ParseOrDefault(ObjectDefenseBox.Text, 0),
                ObjectCategoryBox.Text ?? string.Empty,
                ParseOrDefault(ObjectConcentrationBox.Text, 0),
                ObjectDescriptionBox.Text ?? string.Empty,
                ParseOrDefault(SpellRangeBox.Text, 0),
                ParseOrDefault(SpellConcentrationBox.Text, 0),
                SpellDescriptionBox.Text ?? string.Empty,
                ParseList(ArmorProfsBox.Text),
                ParseList(WeaponProfsBox.Text),
                ParseList(ToolProfsBox.Text),
                ParseList(SavingThrowProfsBox.Text),
                ParseList(SkillProfsBox.Text),
                string.Empty, // BaseName - assigned on save
                0, // BaseId - assigned on save
                string.Empty // BaseTimestamp - assigned on save
            );

            return ch;
        }

        private void SaveCharacter(bool closeAfterSave)
        {
            var ch = BuildCharacterFromUI();

            // assign base metadata if creating new
            if (_editingIndex >= 0 && _editingIndex < CharactersStore.Characters.Count)
            {
                // preserve existing base metadata when editing
                var existing = CharactersStore.Characters[_editingIndex];
                ch = ch with { BaseName = existing.BaseName, BaseId = existing.BaseId, BaseTimestamp = existing.BaseTimestamp };
                CharactersStore.Characters[_editingIndex] = ch;
            }
            else
            {
                // generate base metadata
                var nextId = (CharactersStore.Characters.Count > 0) ? CharactersStore.Characters.Max(x => x.BaseId) + 1 : 1;
                var baseName = $"Base_{nextId}";
                var timestamp = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");
                ch = ch with { BaseName = baseName, BaseId = nextId, BaseTimestamp = timestamp };
                CharactersStore.Characters.Add(ch);
            }

            MessageBox.Show("Character saved.", "Saved", MessageBoxButton.OK, MessageBoxImage.Information);

            if (closeAfterSave)
            {
                try
                {
                    if (this.Owner != null)
                    {
                        this.Owner.Show();
                    }
                    else if (Application.Current?.MainWindow != null && Application.Current.MainWindow != this)
                    {
                        Application.Current.MainWindow.Show();
                    }
                }
                catch { }

                this.Close();
            }
            else
            {
                // stay open and reset editor to first tab
                try { CreatorTabControl.SelectedIndex = 0; } catch { }
            }
        }

        private void DoneButton_Click(object sender, RoutedEventArgs e)
        {
            // If not on last tab, advance to next tab instead of saving
            if (CreatorTabControl != null && CreatorTabControl.SelectedIndex < CreatorTabControl.Items.Count - 1)
            {
                CreatorTabControl.SelectedIndex++;
                return;
            }

            // on last tab save but remain open
            SaveCharacter(false);
        }

        private void SaveCloseButton_Click(object sender, RoutedEventArgs e)
        {
            SaveCharacter(true);
        }
    }
}
