﻿using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Diagnostics;
using System.IO;
using System.Threading.Tasks;

namespace IMMOAwpf
{
    public partial class MainWindow : Window
    {
        private const string CExePath = @"C:\Users\Acer\Desktop\IMMOA\Programas\Generador_Personajes.exe";
        private const string JavaJarPath = @"C:\Users\Acer\OneDrive\Documentos\NetBeansProjects\ThisFr\dist\IMMOA_1.0.jar";

        public MainWindow()
        {
            InitializeComponent();
            LoadBackgroundSafely();
            AppConfig.Load();
        }

        private void LoadBackgroundSafely()
        {
            try
            {
                var bmp = new BitmapImage();
                bmp.BeginInit();
                //bmp.UriSource = new System.Uri("pack://siteoforigin:,,,/Background.png", System.UriKind.Absolute);
                bmp.UriSource = new System.Uri(@"C:\Users\Acer\source\repos\IMMOAwpf\IMMOAwpf\Background.png", System.UriKind.Absolute);
                bmp.CacheOption = BitmapCacheOption.OnLoad;
                bmp.EndInit();

                this.Background = new ImageBrush(bmp) { Stretch = Stretch.Fill };
            }
            catch
            {
                // ignore load errors
            }
        }

        private void GoToSecondWindow_Click(object sender, RoutedEventArgs e)
        {
            Window1 sw = new Window1();
            sw.Owner = this; // opcional: establece relación de propietario
            sw.Closed += (s, args) => this.Show(); // al cerrar Window1, vuelve a mostrar MainWindow
            sw.Show();
            this.Hide();
        }

        private void DisplayCharacters_Click(object sender, RoutedEventArgs e)
        {
            var w = new DisplayCharactersWindow();
            w.Owner = this;
            w.ShowDialog();
        }
        
        private void OpenConfig_Click(object sender, RoutedEventArgs e)
        {
            var w = new ConfigWindow { Owner = this };
            w.ShowDialog();
            // reload config in case it changed
            AppConfig.Load();
        }

        private async void GenerateButton_Click(object sender, RoutedEventArgs e)
        {
            if (!int.TryParse(GenerateCountBox.Text, out var count) || count <= 0)
            {
                MessageBox.Show("Introduce un número válido de personajes.", "Error", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            GenerateButton.IsEnabled = false;
            string tempOutputFile = null;
            try
            {
                // Run the C exe with the count as stdin
                tempOutputFile = System.IO.Path.GetTempFileName();

                var psi = new ProcessStartInfo
                {
                    FileName = CExePath,
                    UseShellExecute = false,
                    RedirectStandardInput = true,
                    RedirectStandardOutput = true,
                    RedirectStandardError = true,
                    CreateNoWindow = true
                };

                using (var process = Process.Start(psi))
                {
                    if (process == null)
                    {
                        MessageBox.Show("No se pudo iniciar el generador externo.", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
                        return;
                    }

                    // write the number and newline to the program's stdin
                    await process.StandardInput.WriteLineAsync(count.ToString());
                    await process.StandardInput.FlushAsync();
                    process.StandardInput.Close();

                    // capture stdout to a temp file
                    using (var fs = new System.IO.FileStream(tempOutputFile, System.IO.FileMode.Create, System.IO.FileAccess.Write, System.IO.FileShare.None))
                    using (var sw = new System.IO.StreamWriter(fs, Encoding.UTF8))
                    {
                        while (!process.StandardOutput.EndOfStream)
                        {
                            var line = await process.StandardOutput.ReadLineAsync();
                            if (line == null) break;
                            await sw.WriteLineAsync(line);
                        }
                    }

                    // wait for process to exit
                    await Task.Run(() => process.WaitForExit());

                    if (process.ExitCode != 0)
                    {
                        var err = await process.StandardError.ReadToEndAsync();
                        MessageBox.Show($"Generador falló: {err}", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
                        return;
                    }
                }

                // Prefer the C program's persistent output file if it exists; use config path if set, otherwise use default
                const string DefaultCOutput = @"C:\Users\Acer\Desktop\IMMOA\csv_y_txt\characters.csv";
                var configuredPath = string.IsNullOrWhiteSpace(AppConfig.CustomCOutputPath) ? DefaultCOutput : AppConfig.CustomCOutputPath;

                string contentToParse = null;
                if (!string.IsNullOrWhiteSpace(configuredPath) && System.IO.File.Exists(configuredPath) && new FileInfo(configuredPath).Length > 0)
                {
                    contentToParse = System.IO.File.ReadAllText(configuredPath, Encoding.UTF8);
                    CharactersStore.LastGeneratedRaw = contentToParse ?? string.Empty;
                }
                else if (!string.IsNullOrEmpty(tempOutputFile) && System.IO.File.Exists(tempOutputFile))
                {
                    contentToParse = System.IO.File.ReadAllText(tempOutputFile, Encoding.UTF8);
                    CharactersStore.LastGeneratedRaw = contentToParse ?? string.Empty;
                }
                else
                {
                    CharactersStore.LastGeneratedRaw = string.Empty;
                }

                // contentToParse may now contain either the raw data or be null; try to parse it into Character objects
                using (var sr = new System.IO.StringReader(contentToParse ?? string.Empty))
                {
                    string line;
                    while ((line = sr.ReadLine()) != null)
                    {
                        var parts = line.Split(',');
                        // expect at least up to index 42 per spec
                        if (parts.Length < 43) continue;

                        int ParseIntAt(int idx, int def) => (idx < parts.Length && int.TryParse(parts[idx], out var v)) ? v : def;
                        decimal ParseDecAt(int idx, decimal def) => (idx < parts.Length && decimal.TryParse(parts[idx], out var v)) ? v : def;
                        string At(int idx) => (idx < parts.Length) ? parts[idx] : string.Empty;

                        var armor = new List<string>();
                        if (parts.Length > 30) { if (!string.IsNullOrWhiteSpace(At(30))) armor.Add(At(30)); if (!string.IsNullOrWhiteSpace(At(31))) armor.Add(At(31)); }
                        var weapon = new List<string>();
                        if (parts.Length > 32) { if (!string.IsNullOrWhiteSpace(At(32))) weapon.Add(At(32)); if (!string.IsNullOrWhiteSpace(At(33))) weapon.Add(At(33)); }
                        var tool = new List<string>();
                        if (parts.Length > 34) { if (!string.IsNullOrWhiteSpace(At(34))) tool.Add(At(34)); if (!string.IsNullOrWhiteSpace(At(35))) tool.Add(At(35)); }
                        var saving = new List<string>();
                        if (parts.Length > 36) { if (!string.IsNullOrWhiteSpace(At(36))) saving.Add(At(36)); if (!string.IsNullOrWhiteSpace(At(37))) saving.Add(At(37)); }
                        var skill = new List<string>();
                        if (parts.Length > 38) { if (!string.IsNullOrWhiteSpace(At(38))) skill.Add(At(38)); if (!string.IsNullOrWhiteSpace(At(39))) skill.Add(At(39)); }

                        var c = new Character(
                            At(0), // Name
                            At(1), // Race
                            At(11), // Class (class_name)
                            ParseIntAt(5, 10), // Strength
                            ParseIntAt(6, 10), // Dexterity
                            ParseIntAt(7, 10), // Constitution
                            ParseIntAt(8, 10), // Intelligence
                            ParseIntAt(9, 10), // Wisdom
                            ParseIntAt(10, 10), // Charisma
                            string.Empty, // Hairstyle
                            string.Empty, // HairColor
                            string.Empty, // FacialHair
                            string.Empty, // SkinTone
                            new System.Collections.Generic.List<string>(), // Proficiencies
                            ParseIntAt(2, 1), // Gender
                            ParseIntAt(3, 170), // HeightCm
                            ParseIntAt(4, 30), // SpeedFeet
                            At(11), // ClassName
                            ParseIntAt(12, 8), // ClassHitDie
                            ParseIntAt(13, 8), // HpHitDie
                            ParseIntAt(14, 0), // HpConMod
                            ParseIntAt(15, 0), // AoeShape
                            ParseIntAt(16, 0), // AoeSize
                            ParseIntAt(17, 0), // AoeMoveable
                            ParseIntAt(18, 0), // ComponentConsumable
                            ParseDecAt(19, 0m), // ComponentCost
                            ParseIntAt(20, 0), // AbilityPermanent
                            ParseIntAt(21, 0), // EffectPermanent
                            ParseIntAt(22, 0), // ObjectRange
                            ParseIntAt(23, 0), // ObjectDefense
                            At(24), // ObjectCategory
                            ParseIntAt(25, 0), // ObjectConcentration
                            At(26), // ObjectDescription
                            ParseIntAt(27, 0), // SpellRange
                            ParseIntAt(28, 0), // SpellConcentration
                            At(29), // SpellDescription
                            armor, weapon, tool, saving, skill,
                            At(40), // BaseName
                            ParseIntAt(41, 0), // BaseId
                            At(42) // BaseTimestamp
                        );

                        CharactersStore.Characters.Add(c);
                     }
                 }

                MessageBox.Show("Generación completada.", "OK", MessageBoxButton.OK, MessageBoxImage.Information);
            }
            finally
            {
                GenerateButton.IsEnabled = true;
                // clean up temp C output file
                try { if (!string.IsNullOrEmpty(tempOutputFile) && System.IO.File.Exists(tempOutputFile)) System.IO.File.Delete(tempOutputFile); } catch { }
            }
        }

    }
 }