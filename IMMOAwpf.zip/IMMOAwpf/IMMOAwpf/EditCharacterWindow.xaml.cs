using System;
using System.Linq;
using System.Windows;

namespace IMMOAwpf
{
    public partial class EditCharacterWindow : Window
    {
        private Character _original;
        private int _index; // -1 for new
        public Character Result { get; private set; }

        public EditCharacterWindow(Character character, int index)
        {
            InitializeComponent();
            _original = character;
            _index = index;
            LoadCharacter(character);
        }

        private void LoadCharacter(Character c)
        {
            NameBox.Text = c.Name;
            RaceBox.Text = c.Race;
            ClassBox.Text = c.Class;
            ClassNameBox.Text = c.ClassName ?? string.Empty;
            GenderBox.Text = c.Gender.ToString();
            HeightBox.Text = c.HeightCm.ToString();
            SpeedBox.Text = c.SpeedFeet.ToString();
            BaseNameBox.Text = c.BaseName ?? string.Empty;
            BaseIdBox.Text = c.BaseId.ToString();
            BaseTimestampBox.Text = c.BaseTimestamp ?? string.Empty;

            StrBox.Text = c.Strength.ToString();
            DexBox.Text = c.Dexterity.ToString();
            ConBox.Text = c.Constitution.ToString();
            IntBox.Text = c.Intelligence.ToString();
            WisBox.Text = c.Wisdom.ToString();
            ChaBox.Text = c.Charisma.ToString();

            HairstyleBox.Text = c.Hairstyle;
            HairColorBox.Text = c.HairColor;
            FacialHairBox.Text = c.FacialHair;
            SkinToneBox.Text = c.SkinTone;

            ClassHitDieBox.Text = c.ClassHitDie.ToString();
            HpHitDieBox.Text = c.HpHitDie.ToString();
            HpConModBox.Text = c.HpConMod.ToString();

            AoeShapeBox.Text = c.AoeShape.ToString();
            AoeSizeBox.Text = c.AoeSize.ToString();
            AoeMoveableBox.Text = c.AoeMoveable.ToString();
            ComponentConsumableBox.Text = c.ComponentConsumable.ToString();
            ComponentCostBox.Text = c.ComponentCost.ToString();
            AbilityPermanentBox.Text = c.AbilityPermanent.ToString();
            EffectPermanentBox.Text = c.EffectPermanent.ToString();
            ObjectRangeBox.Text = c.ObjectRange.ToString();
            ObjectDefenseBox.Text = c.ObjectDefense.ToString();
            ObjectCategoryBox.Text = c.ObjectCategory;
            ObjectConcentrationBox.Text = c.ObjectConcentration.ToString();
            ObjectDescriptionBox.Text = c.ObjectDescription ?? string.Empty;
            SpellRangeBox.Text = c.SpellRange.ToString();
            SpellConcentrationBox.Text = c.SpellConcentration.ToString();
            SpellDescriptionBox.Text = c.SpellDescription ?? string.Empty;

            ArmorProfsBox.Text = string.Join(";", c.ArmorProfs ?? new System.Collections.Generic.List<string>());
            WeaponProfsBox.Text = string.Join(";", c.WeaponProfs ?? new System.Collections.Generic.List<string>());
            ToolProfsBox.Text = string.Join(";", c.ToolProfs ?? new System.Collections.Generic.List<string>());
            SavingThrowProfsBox.Text = string.Join(";", c.SavingThrowProfs ?? new System.Collections.Generic.List<string>());
            SkillProfsBox.Text = string.Join(";", c.SkillProfs ?? new System.Collections.Generic.List<string>());
        }

        private void SaveButton_Click(object sender, RoutedEventArgs e)
        {
            int ParseInt(string s, int def) => int.TryParse(s, out var v) ? v : def;
            decimal ParseDec(string s, decimal def) => decimal.TryParse(s, out var v) ? v : def;

            var armor = (ArmorProfsBox.Text ?? string.Empty).Split(new[] {';'}, StringSplitOptions.RemoveEmptyEntries).Select(x => x.Trim()).ToList();
            var weapon = (WeaponProfsBox.Text ?? string.Empty).Split(new[] {';'}, StringSplitOptions.RemoveEmptyEntries).Select(x => x.Trim()).ToList();
            var tool = (ToolProfsBox.Text ?? string.Empty).Split(new[] {';'}, StringSplitOptions.RemoveEmptyEntries).Select(x => x.Trim()).ToList();
            var saving = (SavingThrowProfsBox.Text ?? string.Empty).Split(new[] {';'}, StringSplitOptions.RemoveEmptyEntries).Select(x => x.Trim()).ToList();
            var skill = (SkillProfsBox.Text ?? string.Empty).Split(new[] {';'}, StringSplitOptions.RemoveEmptyEntries).Select(x => x.Trim()).ToList();

            var result = new Character(
                NameBox.Text ?? string.Empty,
                RaceBox.Text ?? string.Empty,
                ClassBox.Text ?? string.Empty,
                ParseInt(StrBox.Text, 10),
                ParseInt(DexBox.Text, 10),
                ParseInt(ConBox.Text, 10),
                ParseInt(IntBox.Text, 10),
                ParseInt(WisBox.Text, 10),
                ParseInt(ChaBox.Text, 10),
                HairstyleBox.Text ?? string.Empty,
                HairColorBox.Text ?? string.Empty,
                FacialHairBox.Text ?? string.Empty,
                SkinToneBox.Text ?? string.Empty,
                new System.Collections.Generic.List<string>(),
                // additional fields
                ParseInt(GenderBox.Text, 1),
                ParseInt(HeightBox.Text, 170),
                ParseInt(SpeedBox.Text, 30),
                ClassNameBox.Text ?? string.Empty,
                ParseInt(ClassHitDieBox.Text, 8),
                ParseInt(HpHitDieBox.Text, 8),
                ParseInt(HpConModBox.Text, 0),
                ParseInt(AoeShapeBox.Text, 0),
                ParseInt(AoeSizeBox.Text, 0),
                ParseInt(AoeMoveableBox.Text, 0),
                ParseInt(ComponentConsumableBox.Text, 0),
                ParseDec(ComponentCostBox.Text, 0m),
                ParseInt(AbilityPermanentBox.Text, 0),
                ParseInt(EffectPermanentBox.Text, 0),
                ParseInt(ObjectRangeBox.Text, 0),
                ParseInt(ObjectDefenseBox.Text, 0),
                ObjectCategoryBox.Text ?? string.Empty,
                ParseInt(ObjectConcentrationBox.Text, 0),
                ObjectDescriptionBox.Text ?? string.Empty,
                ParseInt(SpellRangeBox.Text, 0),
                ParseInt(SpellConcentrationBox.Text, 0),
                SpellDescriptionBox.Text ?? string.Empty,
                armor, weapon, tool, saving, skill,
                BaseNameBox.Text ?? string.Empty,
                ParseInt(BaseIdBox.Text, 0),
                BaseTimestampBox.Text ?? string.Empty
            );

            Result = result;

            if (_index >= 0)
            {
                CharactersStore.Characters[_index] = Result;
            }

            this.DialogResult = true;
            this.Close();
        }

        private void CancelButton_Click(object sender, RoutedEventArgs e)
        {
            this.DialogResult = false;
            this.Close();
        }
    }
}
