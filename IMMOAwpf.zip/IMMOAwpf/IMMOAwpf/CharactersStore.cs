using System.Collections.Generic;

namespace IMMOAwpf
{
    public record Character(
        string Name,
        string Race,
        string Class,
        int Strength,
        int Dexterity,
        int Constitution,
        int Intelligence,
        int Wisdom,
        int Charisma,
        string Hairstyle,
        string HairColor,
        string FacialHair,
        string SkinTone,
        List<string> Proficiencies,

        // Additional fields from Java output
        int Gender,
        int HeightCm,
        int SpeedFeet,
        string ClassName,
        int ClassHitDie,
        int HpHitDie,
        int HpConMod,
        int AoeShape,
        int AoeSize,
        int AoeMoveable,
        int ComponentConsumable,
        decimal ComponentCost,
        int AbilityPermanent,
        int EffectPermanent,
        int ObjectRange,
        int ObjectDefense,
        string ObjectCategory,
        int ObjectConcentration,
        string ObjectDescription,
        int SpellRange,
        int SpellConcentration,
        string SpellDescription,
        List<string> ArmorProfs,
        List<string> WeaponProfs,
        List<string> ToolProfs,
        List<string> SavingThrowProfs,
        List<string> SkillProfs,
        string BaseName,
        int BaseId,
        string BaseTimestamp
    );

    public static class CharactersStore
    {
        public static List<Character> Characters { get; } = new List<Character>();

        // Raw output produced by the external Java processor (if any). DisplayCharactersWindow will prefer this when present.
        public static string LastGeneratedRaw { get; set; } = string.Empty;
    }
}
