using System;
using System.Linq;
using System.Windows;

namespace IMMOAwpf
{
    public partial class DisplayCharactersWindow : Window
    {
        public DisplayCharactersWindow()
        {
            InitializeComponent();

            RefreshList();
        }

        private void RefreshList()
        {
            CharactersList.ItemsSource = CharactersStore.Characters.Select(DisplayForList).ToList();

            // enable/disable buttons depending on list
            EditButton.IsEnabled = CharactersStore.Characters.Count > 0;
            DeleteButton.IsEnabled = CharactersStore.Characters.Count > 0;
            OpenInCreatorButton.IsEnabled = CharactersStore.Characters.Count > 0;
        }

        private string DisplayForList(Character c)
        {
            return $"{c.Name} - {c.Race} {c.Class} | STR:{c.Strength} DEX:{c.Dexterity} CON:{c.Constitution} INT:{c.Intelligence} WIS:{c.Wisdom} CHA:{c.Charisma}";
        }

        private void EditButton_Click(object sender, RoutedEventArgs e)
        {
            var idx = CharactersList.SelectedIndex;
            if (idx < 0 || idx >= CharactersStore.Characters.Count)
            {
                MessageBox.Show("Selecciona un personaje v�lido.", "Error", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            var edit = new EditCharacterWindow(CharactersStore.Characters[idx], idx) { Owner = this };
            if (edit.ShowDialog() == true)
            {
                RefreshList();
            }
        }

        private void CharactersList_MouseDoubleClick(object sender, System.Windows.Input.MouseButtonEventArgs e)
        {
            EditButton_Click(sender, e);
        }

        private void DeleteButton_Click(object sender, RoutedEventArgs e)
        {
            var idx = CharactersList.SelectedIndex;
            if (idx < 0 || idx >= CharactersStore.Characters.Count)
            {
                MessageBox.Show("Selecciona un personaje v�lido.", "Error", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            if (MessageBox.Show("Eliminar personaje seleccionado?", "Confirmar", MessageBoxButton.YesNo, MessageBoxImage.Question) == MessageBoxResult.Yes)
            {
                CharactersStore.Characters.RemoveAt(idx);
                RefreshList();
            }
        }

        private void CloseButton_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }

        private void OpenInCreatorButton_Click(object sender, RoutedEventArgs e)
        {
            var idx = CharactersList.SelectedIndex;
            if (idx < 0 || idx >= CharactersStore.Characters.Count)
            {
                MessageBox.Show("Selecciona un personaje.", "Info", MessageBoxButton.OK, MessageBoxImage.Information);
                return;
            }

            var c = CharactersStore.Characters[idx];
            var w = new Window1(c, idx) { Owner = this.Owner ?? Application.Current.MainWindow };
            w.Show();
            this.Close();
        }
    }
}
