using System.Collections.Generic;
using System.Linq;
using System.Windows;
using System.Windows.Controls;

namespace IMMOAwpf
{
    public partial class ProficienciesWindow : Window
    {
        private readonly List<string> _skills = new()
        {
            "Acrobatics (Dex)",
            "Animal Handling (Wis)",
            "Arcana (Int)",
            "Athletics (Str)",
            "Deception (Cha)",
            "History (Int)",
            "Insight (Wis)",
            "Intimidation (Cha)",
            "Investigation (Int)",
            "Medicine (Wis)",
            "Nature (Int)",
            "Perception (Wis)",
            "Performance (Cha)",
            "Persuasion (Cha)",
            "Religion (Int)",
            "Sleight of Hand (Dex)",
            "Stealth (Dex)",
            "Survival (Wis)"
        };

        public List<string> Selected { get; } = new List<string>();

        public ProficienciesWindow()
        {
            InitializeComponent();

            foreach (var s in _skills)
            {
                var rb = new RadioButton { Content = s, GroupName = "skills" }; // RadioButtons would allow single selection; use CheckBox instead
                ChecksPanel.Children.Add(new CheckBox { Content = s });
            }
        }

        private void CancelBtn_Click(object sender, RoutedEventArgs e)
        {
            this.DialogResult = false;
            this.Close();
        }

        private void SaveBtn_Click(object sender, RoutedEventArgs e)
        {
            Selected.Clear();
            foreach (var child in ChecksPanel.Children.OfType<CheckBox>())
            {
                if (child.IsChecked == true)
                    Selected.Add(child.Content.ToString());
            }

            this.DialogResult = true;
            this.Close();
        }
    }
}
